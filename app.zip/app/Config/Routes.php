<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

service('auth')->routes($routes);

$modulesDir = APPPATH . 'Modules';
if (is_dir($modulesDir)) {
    $items = scandir($modulesDir);
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }
        $modulePath = $modulesDir . DIRECTORY_SEPARATOR . $item;
        if (! is_dir($modulePath)) {
            continue;
        }
        $routeFile = $modulePath . DIRECTORY_SEPARATOR . 'Config' . DIRECTORY_SEPARATOR . 'Routes.php';
        if (is_file($routeFile)) {
            require $routeFile;
        }
    }
}