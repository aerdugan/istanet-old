<?php

if (!function_exists('getThemeSettings')) {
    function getThemeSettings()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('themeSettings');
        return $builder->get()->getRow();
    }
}
if (!function_exists('getMobileThemeSettings')) {
    function getMobileThemeSettings()
    {
        // Service loader
        $db = \Config\Database::connect();
        $builder = $db->table('mobileThemeSettings');

        // Veriyi sorgula
        return $builder->get()->getRow();
    }
}

if (!function_exists('getCompanyDefaultAddress')) {
    function getCompanyDefaultAddress()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('contactSettings');
        $contact_settings = $builder->where('rank', 0)->get()->getRow();
        echo $contact_settings->address;
    }
}
if (!function_exists('getCompanyDefaultLocation')) {
    function getCompanyDefaultLocation()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('contactSettings');
        $contact_settings = $builder->where('rank', 0)->get()->getRow();
        echo $contact_settings->address_location;
    }
}
if (!function_exists('getCompanyDefaultPhone')) {
    function getCompanyDefaultPhone()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('contactSettings');
        $contact_settings = $builder->where('rank', 0)->get()->getRow();
        echo $contact_settings->phone_1;
    }
}
if (!function_exists('getCompanyDefaultEmail')) {
    function getCompanyDefaultEmail()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('contactSettings');
        $contact_settings = $builder->where('rank', 0)->get()->getRow();
        echo $contact_settings->email;
    }
}
if (!function_exists('setThemeFirstColor')) {
    function setThemeFirstColor()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('themeSettings');
        $theme_settings = $builder->get()->getRow();
        echo $theme_settings->colorCode;
    }
}
if (!function_exists('setThemeSecondColor')) {
    function setThemeSecondColor()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('themeSettings');
        $theme_settings = $builder->get()->getRow();
        echo $theme_settings->colorCode2;
    }
}

if (!function_exists('setCompanyName')) {
    function setCompanyName()
    {
        setting('site.logo.company_name');
    }
}

if (!function_exists('setContentBox')) {
    function setContentBox(){
        echo "https://cdn.istanet.com/cBox/cBox5830/";
    }
}

if (!function_exists('setCompanyName')) {
    function setCompanyName()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('logoSettings');
        $logo_settings = $builder->get()->getRow();
        echo $logo_settings->company_name;
    }
}
if (!function_exists('companyLongName')) {
    function companyLongName()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('logoSettings');
        $logo_settings = $builder->get()->getRow();
        echo $logo_settings->companyLongName;
    }
}
if (!function_exists('getCompanyDefaultAddress')) {
    function getCompanyDefaultAddress()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('contactSettings');
        $contact_settings = $builder->where('rank', 0)->get()->getRow();
        echo $contact_settings->address;
    }
}
if (!function_exists('getCompanyDefaultLocation')) {
    function getCompanyDefaultLocation()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('contactSettings');
        $contact_settings = $builder->where('rank', 0)->get()->getRow();
        echo $contact_settings->address_location;
    }
}
if (!function_exists('getCompanyDefaultPhone')) {
    function getCompanyDefaultPhone()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('contactSettings');
        $contact_settings = $builder->where('rank', 0)->get()->getRow();
        echo $contact_settings->phone_1;
    }
}
if (!function_exists('getCompanyDefaultEmail')) {
    function getCompanyDefaultEmail()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('contactSettings');
        $contact_settings = $builder->where('rank', 0)->get()->getRow();
        echo $contact_settings->email;
    }
}

function buildTree(array $elements, $parentId = 0, $depth = 0, $maxDepth = 100) {
    if ($depth > $maxDepth) {
        return [];
    }

    $branch = [];
    foreach ($elements as $element) {
        if (is_object($element)) {
            if ($element->id == $parentId) {
                continue; // kendine bağlı olanları atla
            }
            if ($element->parent_id == $parentId) {
                $children = buildTree($elements, $element->id, $depth + 1, $maxDepth);
                if ($children) {
                    $element->children = $children;
                }
                $branch[] = $element;
            }
        }
    }
    return $branch;
}

if (!function_exists('getAllPages')) {
    function getAllPages() {
        $db = \Config\Database::connect();
        $session = \Config\Services::session();
        $lang = $session->get('data_lang');

        $builder = $db->table('pages'); // Specify the table 'pages'

        $query = $builder->where('data_lang', $lang)
            ->where('isActive', 1)
            ->where('isHeader', 1)
            ->orderBy('rank', 'ASC')  // Optional: Order by 'rank'
            ->get();

        return $query->getResult();
    }
}

if (!function_exists('getFrontEndLanguageMenu')) {
    function getFrontEndLanguageMenu(): string
    {
        helper('language');

        $session = session();
        $currentLang = $session->get('data_lang') ?? getDefaultLanguage();
        $activeLanguages = getActiveLanguages(); // sadece isActive = 1 diller

        $menuItems = '';
        $activeLang = strtoupper($currentLang);

        foreach ($activeLanguages as $lang) {
            $code = $lang['shorten'];
            if ($code === $currentLang) continue;

            $menuItems .= '<li class="custom-width">
                                <a href="' . base_url('lang/' . $code) . '">' . strtoupper(esc($code)) . '</a>
                           </li>';
        }

        $menuHtml = '<li class="menu-item-has-children no-bg">
                        <a href="#">' . esc(strtoupper($activeLang)) . '</a>
                        <ul class="sub-menu clearfix">' . $menuItems . '</ul>
                     </li>';

        return $menuHtml;
    }
}
