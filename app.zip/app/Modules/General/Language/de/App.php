<?php
return [
    // MENUS
    "menu_general" => "General Settings",


    // MODULES
];