<?php
return [
    // MENUS
    "menu_general" => "Genel Ayarlar",





    // MODULES
];