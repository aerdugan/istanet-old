<?php
return [
    // MENUS
    "menu_page" => "Page Management",
    "page_list" => "Page List",
    "page_add" => "Add New Page",
    "page_edit" => "Edit Page",
    "page_title" => "Page Title",
    "page_url" => "Page Url",
    "page_status_change" => "Page Status Changed.",
    "page_status_error" => "Error updating page status.",

    // MODULES
];