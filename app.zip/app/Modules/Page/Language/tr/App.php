<?php
return [
    // MENUS
    "menu_page" => "Sayfa Yönetimi",
    "page_list" => "Sayfa Listesi   ",
    "page_add" => "Yeni Sayfa Ekle",
    "page_edit" => "Edit Page",
    "page_title" => "Page Title",
    "page_url" => "Page Url",
    "page_status_change" => "Page Status Changed.",
    "page_status_error" => "Error updating page status.",

    // MODULES
];