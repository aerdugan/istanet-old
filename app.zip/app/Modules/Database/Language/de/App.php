<?php
return [
    // MENUS
    "menu_task" => "Tasks",
    "menu_task_list" => "List",
    "menu_task_add" => "Add",

    // MODULES
];