<?php
return [
    'table_name'    => 'Tablo Adı',
    'row_count'     => 'Satır Sayısı',
    'download'      => 'İndir',
    'truncate'      => 'Boşalt',
    'upload'        => 'Yükle',
    'download_sql'  => 'SQL İndir',
    'truncate_sql'  => 'Boşalt',
    'upload_sql'    => 'SQL Yükle',
];
