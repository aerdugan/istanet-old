<?php
return [
    'table_name'    => 'Table Name',
    'row_count'     => 'Row Count',
    'download'      => 'Download',
    'truncate'      => 'Truncate',
    'upload'        => 'Upload',
    'download_sql'  => 'Download SQL',
    'truncate_sql'  => 'Truncate',
    'upload_sql'    => 'Upload SQL',
];
