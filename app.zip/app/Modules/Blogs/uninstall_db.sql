-- ----------------------------
--  Drop structure for `task`
--  Use [DB_PREFIX] in front of the tables to implement the default database prefix.
-- ----------------------------
DROP TABLE `[DB_PREFIX]blogs`;
DROP TABLE `[DB_PREFIX]blogCategories`;
DROP TABLE `[DB_PREFIX]blogImages`;
