<?php

namespace App\Modules\Users\Models;

use CodeIgniter\Shield\Models\UserModel as ShieldUserModel;

class UserModel extends ShieldUserModel
{
    // Shield UserModel
}
