<?php
namespace App\Modules\Dashboard\Config;

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->group('dashboard', [
    'namespace' => 'App\Modules\Dashboard\Controllers',
    'filter'    => 'session', // Shield oturum zorunlu
], static function ($routes) {

    // ikinci seviye: dil filtresi
    $routes->group('', ['filter' => 'languageInit'], static function ($routes) {
        $routes->get('/', 'Dashboard::index', ['as' => 'dashboard']);
        $routes->get('change/(:segment)', 'Dashboard::change/$1');
    });
});