<?php
namespace App\Modules\Dashboard\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\LanguageModel; // dosyanın başına ekle

class Dashboard extends BaseController
{
    public function index(): ResponseInterface|string
    {
        if (!user_can('Dashboard.Dashboard.index')) {
            // SweetAlert mesajı ayarlıyoruz
            session()->setFlashdata('swal', [
                'type'    => 'error',
                'title'   => 'Yetki Hatası',
                'message' => 'Bu sayfayı görmeye yetkiniz yok.',
            ]);

            return redirect()->to('/dashboard');
        }

        helper('auth');

        $data = ['title' => 'Yönetim Paneli'];
        // Not: View path'inde de App\ ile başlayalım
        return view('App\Modules\Dashboard\Views\index', $data);
    }


    public function change(string $langCode)
    {
        if (!user_can('Dashboard.Dashboard.change')) {
            // SweetAlert mesajı ayarlıyoruz
            session()->setFlashdata('swal', [
                'type'    => 'error',
                'title'   => 'Yetki Hatası',
                'message' => 'Bu sayfayı görmeye yetkiniz yok.',
            ]);

            return redirect()->to('/dashboard');
        }

        helper('language');

        // geçerli kod mu?
        $codes = array_column(getActiveLanguages(), 'shorten');
        if (in_array($langCode, $codes, true)) {
            session()->set('data_lang', $langCode);
            service('request')->setLocale($langCode); // opsiyonel
        }
        return redirect()->to('/dashboard');
    }
}