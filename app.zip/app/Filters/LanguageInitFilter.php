<?php
// app/Filters/LanguageInitFilter.php
namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\{RequestInterface, ResponseInterface};

class LanguageInitFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $session = session();

        if ($session->has('data_lang') && $session->get('data_lang')) {
            service('request')->setLocale($session->get('data_lang'));
            return;
        }

        // YANLIŞ: helper('language');  // <-- CI'nin kendi helper'ı, sil
        helper('admin');              // <-- senin helper'ını yükle

        $code = \getDefaultLanguage();  // <-- global fonksiyon, başına \ koy
        $session->set('data_lang', $code);
        service('request')->setLocale($code);
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null) {}
}