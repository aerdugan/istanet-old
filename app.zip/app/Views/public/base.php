<?php
$themeSettings = getThemeSettings();
$settings = session()->get('settings');

$activeLanguages = getActiveLanguages();
$availableLangCodes = array_column($activeLanguages, 'shorten');

$language = session('lang');

if (!$language || !in_array($language, $availableLangCodes)) {
    $language = getDefaultLanguage();
    session()->set('lang', $language); // İsteğe bağlı
}
?>
<!doctype html>
<html lang="<?= esc($language) ?>" dir="ltr" class="no-js">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="apple-touch-icon-precomposed" type="image/x-icon" href="<?= setting('site.logo.favicon')?>" sizes="72x72" />
    <link rel="apple-touch-icon-precomposed" type="image/x-icon" href="<?= setting('site.logo.favicon')?>" sizes="114x114" />
    <link rel="apple-touch-icon-precomposed" type="image/x-icon" href="<?= setting('site.logo.favicon')?>" sizes="144x144" />
    <link rel="apple-touch-icon-precomposed" type="image/x-icon" href="<?= setting('site.logo.favicon')?>" />
    <link rel="alternate" hreflang="tr" href="<?= base_url('tr' . $_SERVER['REQUEST_URI']) ?>" />
    <link rel="alternate" hreflang="en" href="<?= base_url('en' . $_SERVER['REQUEST_URI']) ?>" />
    <link rel="alternate" hreflang="de" href="<?= base_url('de' . $_SERVER['REQUEST_URI']) ?>" />
    <?= $this->renderSection('head') ?>
    <link rel="icon" type="image/png" href="<?= setting('site.logo.favicon')?>" sizes="32x32">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400italic,400,600,600italic,700,800,800italic" rel="stylesheet" type="text/css">
    <link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="https://cdn.istanet.com/public/Kallyas/css/bootstrap.css" type="text/css" media="all">
    <?= $this->renderSection('style') ?>
    <link rel="stylesheet" href="https://cdn.istanet.com/public/Kallyas/fonts/font-awesome/css/font-awesome.min.css" type="text/css" media="all">
    <link rel="stylesheet" href="<?=site_url("template/public/")?>template.min.css" type="text/css" media="all">
    <link rel="stylesheet" href="https://cdn.istanet.com/public/Kallyas/css/responsive.min.css" type="text/css" media="all">
    <link rel="stylesheet" href="https://cdn.istanet.com/public/Kallyas/css/base-sizing.min.css" type="text/css" media="all">

    <link rel="stylesheet" href="<?=site_url("template/public/")?>custom.css" type="text/css" />
    <script type="text/javascript" src="https://cdn.istanet.com/public/Kallyas/js/modernizr.min.js"></script>
    <script type="text/javascript" src="https://cdn.istanet.com/public/Kallyas/js/jquery.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Calibri&display=swap');
        body {
            font-family: Calibri, 'Segoe UI', sans-serif !important;
        }
    </style>
</head>
<body>
<div id="page_wrapper" class="sticky-header">
    <?php
    if (isset($themeSettings) && isset($themeSettings->setHeader)) {
        $footerPath = FCPATH . 'template/header/' . $themeSettings->setHeader . '.php';
        if (is_file($footerPath)) {
            include $footerPath;
        }
    }
    ?>


    <?= $this->renderSection('breadcrumb') ?>
    <?= $this->renderSection('content') ?>

    <?php
    if (isset($themeSettings) && isset($themeSettings->setFooter)) {
        $footerPath = FCPATH . 'template/footer/' . $themeSettings->setFooter . '.php';
        if (is_file($footerPath)) {
            include $footerPath;
        }
    }
    ?>

</div>
<a href="#" id="totop">TOP</a>
<script type="text/javascript" src="https://cdn.istanet.com/public/Kallyas/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdn.istanet.com/public/Kallyas/js/kl-plugins.js"></script>
<?= $this->renderSection('script') ?>
<script type="text/javascript" src="<?=site_url("template/public/")?>kl-scripts.min.js"></script>
<script type="text/javascript" src="<?=site_url("template/public/")?>kl-custom.js"></script>
</body>
</html>